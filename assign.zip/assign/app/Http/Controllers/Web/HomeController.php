<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\FormList;
use Auth;
use Illuminate\Support\Facades\Hash;


class HomeController extends Controller
{   


  public function index($slug)
  {

  	$code = FormList::where('form_code', $slug)->value('form_code');
  	$data = compact('code');
  	return view('display-form', $data);
  }

  public function home()
  {
  	return view('welcome');
  }

}
