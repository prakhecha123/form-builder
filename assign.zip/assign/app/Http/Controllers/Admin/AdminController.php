<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Admin;
use App\Models\User;
use Auth;
use Response;
use Hash;
class AdminController extends Controller
{
    public function index()
    {
    	return view('admin.login');
    }

    public function checkLogin(Request $request)
    {
    	if($request->isMethod('post'))
       {
         	$rules = array(
                'username'  => 'required',
                'password'  => 'required'
                );

	        $validator = Validator::make($request->all(), $rules);
	        if($validator->fails())
	        {
	            return redirect()->back()->withErrors($validator)->withInput();
	       	}
      }

      if (Auth::guard('admin')->attempt(['username' => $request->username, 'password' => $request->password], $request->get('remember'))) {

        return redirect()->route('admin.dashboard');
      }
      else{
      		return redirect()->back()->with('warning','something is wrong');
      } 
    }

    public function logoutAdmin(Request $request)
    {
      Auth::guard('admin')->logout();
      return redirect()->route('admin.index');
    }

    public function dashboard()
    {
      return view('admin.pages.index');
    }

    public function editProfile()
    {
    	$admin = Auth::guard('admin')->user();
    	$data  = compact('admin');
    	return view('admin.pages.profile.edit_profile', $data);
    }

    public function saveProfile(request $request)
    {
    	if($request->isMethod('post'))
      {
        $rules = array(
         	'Name'      => 'required',
          'UserName'  => 'required',
          'Email'     => 'required'
          );

	      $validator = Validator::make($request->all(), $rules);
	      if($validator->fails())
	      {
	         return redirect()->back()->withErrors($validator)->withInput();
	      }
      }
     	$admin = Auth::guard('admin')->user();
     	$admin->name 		= $request->Name;
     	$admin->username 	= $request->UserName;
     	$admin->email 		= $request->Email;

     	if($request->Profile !='')
    	{
        	$image = url('public/admin/images/profile'.$admin->profile_image);
        	if (file_exists($image)) 
        	{
           	File::delete($image);
        	}

        	$adminProfile = time().'_adminprofile'.'.'.$request->Profile->guessClientExtension();
        	$upload_path  = 'public/admin/images/profile/';
        	$request->Profile->move($upload_path, $adminProfile);
        	$admin->profile_image  = $adminProfile;    
    	}

     	$admin->save();
     	return redirect()->back()->with('success', 'Updated your profile');
    }

    public function changePassword()
    {
        return view('admin.pages.profile.change_password');
    }

    public function savePassword(Request $request)
    {
      	$request->validate([
          	'CurrentPassword'     => ['required'],
          	'NewPassword'         => ['required'],
          	'NewConfirmPassword'  => ['same:NewPassword']
      		]);
      	$check = Hash::check($request->CurrentPassword, Auth::guard('admin')->user()->password);

      	if($check)
      	{
          	Admin::find(Auth::guard('admin')->user()->id)->update(['password'=> Hash::make($request->NewPassword)]);
          	return redirect()->back()->with('success','Password Updated Successfully!');
      	}else{
          	return redirect()->back()->with('error','Current password not match');
      	}
    }

    public function storee()
    {
      var_dump("I am here"); exit;
    }
}
