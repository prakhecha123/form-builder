<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Admin;
use App\Models\User;
use App\Models\FormList;
use App\Models\ResponseList;
use App\Models\Responses;
use Auth;
use Response;
use Hash;

class ManageFormController extends Controller
{
    public function index()
    {
    	$forms   = FormList::orderBy('id', 'ASC')->paginate(50);
    	$data           = compact('forms');
    	return view('admin.pages.form.index', $data);
    }

    public function add()
    {
	return view('admin.pages.form.add_form');
    }

    public function edit($id)
    {   

    	$form = FormList::where(['id' => $id])->first();
    	$data        = compact('form');
    	return view('admin.pages.form.edit_form', $data);
    }


    public function store(Request $request)
    {
    	if($request->isMethod('post'))
       	{


       		$resp = array();
	        $loop = true;
	        $code = $request->form_code;
	        $form_data = $request->form_data;
	        $form_code = NULL;
	        if(empty($form_code)){
	            while($loop == true){
	                $code=mt_rand(0,9999999999);
	                $code = sprintf("%'.09d",$code);
	                $chk = FormList::where('form_code', $code)->get();
	                $chk = $chk->count();
	                if($chk <= 0)
	                    break;
	            }
	        }
	        $fname = $code.".blade.php";

	       

	        /* php artisan migrate */
		   // $create_form =  \Artisan::call($fname);

		   // var_dump($form_data); exit;

	        $create_form = file_put_contents(base_path().'/resources/views/'.$fname,$form_data);

	        if(!$create_form){
	            $resp['status'] = 'failed';
	            $resp['error'] = 'error occured while saving the form';
	            return json_encode($resp);
	            exit;
	        }



	        if(empty($form_code)) {
	        	$formList = new FormList;
		        $formList->form_code = $code;
		        $formList->title = $request->title;
		        $formList->description = $request->description;
		        $formList->fname = $fname;
		        $save_form = $formList->save();
	        } else {
	        	$formList  = FormList::where('form_code', $form_code)->first();
	        	$formList->form_code = $code;
		        $formList->title = $request->title;
		        $formList->description = $request->description;
		        $formList->fname = $fname;
		        $save_form = $formList->save();
	        }
	            
	        
	        	
	        if($save_form){
	            return response()->json([ 'status'=> 'success'], 200);
	        }else{
	            return response()->json([ 'status'=> 'failed'], 400);
	            
	        }
	        
            
        }
    }

    // To delete the existing service
    public function delete($id)
    {
    	$from = FormList::where(['id' => $id])->first();
    	$from->delete();
    	return redirect()->route('admin.form')->with('success', 'Form successfully deleted');
    }
}
