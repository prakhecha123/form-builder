
<!DOCTYPE html>
<html lang="en">
<style>
    /* canvas {
        height: 250px !important
    } */
    
    table th,
    table td {
        padding: 3px !important
    }
</style>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Builder</title>

    <link rel="stylesheet" href="{{ asset('/fontawesome-free/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('/DataTables/datatables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('/css/custom.css') }}">

    <script src="{{ asset('/js/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset('/js/popper.min.js') }}"></script>
    <script src="{{ asset('/js/jquery-ui.js') }}"></script>
    <script src="{{ asset('/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('/DataTables/datatables.min.js') }}"></script>
    <script src="{{ asset('/js/script.js') }}"></script>


    <script>
        var form_code = "{{$code}}";
    </script>
    <script src="{{ asset('/js/form-build-display.js') }}"></script>
</head>

<body class='bg-dark'>
    <div class="container pt-4">
        @include($code) 
        <div class="w-100 d-flex justify-content-center">
            <button class="btn btn-primary" form="form-data" id="">Sumbit</button>
        </div>
    </div>
</body>



</html>