@extends('admin.layout.default')
@section('title', 'Change Password')
@section('content')
<div class="app-content content container-fluid">
  <div class="content-wrapper">
    <div class="content-header row">
    </div>
    <div class="content-body"><!-- stats -->
      @if(session()->has('alert-success'))
        <div class="alert alert-success alert-dismissible fade in mb-2" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <strong>Success!</strong> {{ session()->get('alert-success') }} 
        </div>
      @endif
      <section id="basic-form-layouts">
        <div class="match-height">
          <div class="card p-0">
            <div class="card-header">
              <h4 class="card-title" id="basic-layout-form">Change Password</h4>
              <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
              <div class="heading-elements">
                <ul class="list-inline mb-0">
                  <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                  <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                  <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                  <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                </ul>
              </div>
            </div>
            <div class="card-body collapse in">
              <div class="card-block">
                <form class="form" method="post" enctype="multipart/form-data">
                  @csrf
                  <div class="form-body">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="projectinput1">Current Password</label>
                          <input type="text" class="form-control" placeholder="current password" name="CurrentPassword">
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="projectinput2">New Password</label>
                          <input type="password" class="form-control" placeholder="new password" name="NewPassword" >
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="projectinput3">Confirm Password</label>
                          <input type="password" class="form-control" placeholder="confirm password" name="NewConfirmPassword" >
                        </div>
                      </div>
                    </div>
                    <div class="form-actions">
                      <button type="reset" class="btn btn-warning mr-1">
                        <i class="icon-cross2"></i> Cancel
                      </button>
                      <button type="submit" class="btn btn-primary">
                        <i class="icon-check2"></i> Save
                      </button>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>
@endsection