@extends('admin.layout.default')
@section('title', 'Manage Forms')
@section('content')
<div class="app-content content container-fluid">
	<div class="content-wrapper">  
	    <div class="content-body"><!-- Basic form layout section start -->
			<section id="basic-form-layouts">
				<div class="match-height">
			        <div class="card p-0">
			            <div class="card-header">
			                <h4 class="card-title">All Forms</h4>
			                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
			                <div class="heading-elements">
			                    <ul class="list-inline mb-0">
			                    	<li><a href="{{route('admin.form.add')}}"><button type="button" class="btn btn-primary">+New Form</button></a></li>
			                        <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
			                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
			                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li> 
			                    </ul>
			                </div>
			            </div>
			            <div class="card-body collapse in">
				            <div class="card-block">
				            	@if(session('success'))
			                        <div class="alert alert-success">{{session('success')}}</div>
			                    @endif
				                <div class="table-responsive">
				                    <table class="table">
				                        <thead class="thead-inverse">
				                            <tr>
				                                <th>#</th>
				                                <th>Date Time</th>
				                                <th>Code</th>
				                                <th>Title</th>
				                                <th>Url</th>
				                                <th class="list_action01">Action</th>
				                            </tr>
				                        </thead>
				                        <tbody>
				                        	@if(!empty($forms))
				                        		@foreach($forms as $key=>$from_data)
				                        	  		<tr>
				                                		<td>{{++$key}}</td>
				                                		<td>{{date("M d,Y h:i A",strtotime($from_data->created_at))}}</td>
				                                		<td>{{$from_data->form_code}}</td>
				                                		<td>{{$from_data->title}}</td>
				                                		<td><a href="{{route('form.slug', $from_data->form_code)}}" target="_blank">{{route('form.slug', $from_data->form_code)}}</a></td>
				                                		
	      												<td class="list_action01">
	      													<!-- <a href="{{route('admin.form.edit', ['id'=>$from_data->id])}}"><button type="button" class="btn btn-warning">Edit</button></a> -->
	      													<a href="{{route('admin.form.delete', $from_data->id)}}" onclick="return confirm('Are you sure?')"><button type="button" class="btn btn-danger" >Delete</button></a>
	      												</td>
				                            		</tr>
				                            	@endforeach
			                            	@else
			                            	<span>Record not available</span>
			                            	@endif
				                        </tbody>
				                    </table>
				                    {{$forms->links()}}
				                </div>
				            </div>
			            </div>
			        </div>
				</div>
			</section>
		</div>
	</div>
</div>
@endsection