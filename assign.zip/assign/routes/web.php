<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\ManageFormController;
use App\Http\Controllers\Web\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/form/{slug}', [HomeController::class, 'index'])->name('form.slug');



Route::get('/web-admin',[AdminController::class,'index'])->name('admin.index');
Route::post('/web-admin',[AdminController::class,'checkLogin'])->name('admin.checklogin');
Route::get('/web-admin/logout',[AdminController::class,'logoutAdmin'])->name('admin.logout');



Route::post('/form-store',[ManageFormController::class,'store']);

Route::prefix('web-admin')->middleware('AdminAuth')->name('admin.')->group(function()
{
	Route::get('/dashboard',[AdminController::class, 'dashboard'])->name('dashboard');

	Route::get('/edit-profile',[AdminController::class, 'editProfile'])->name('aditProfile');
	Route::post('/edit-profile',[AdminController::class, 'saveProfile'])->name('aditProfile');
	Route::get('/change-password',[AdminController::class, 'changePassword'])->name('changePassword');
	Route::post('/change-password',[AdminController::class, 'savePassword'])->name('changePassword');


	// 
	Route::get('/form',[ManageFormController::class, 'index'])->name('form');
	Route::get('/form-add',[ManageFormController::class, 'add'])->name('form.add');
	Route::get('/form-edit/{id}',[ManageFormController::class, 'edit'])->name('form.edit');
	Route::get('/form-delete/{id}',[ManageFormController::class, 'delete'])->name('form.delete');
	//Route::post('/form-store',[ManageFormController::class, 'store'])->name('form.store');
	
});