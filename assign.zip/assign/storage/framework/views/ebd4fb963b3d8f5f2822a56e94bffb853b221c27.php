<?php $__env->startSection('title', 'Service Edit'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-content content container-fluid">
	<div class="content-wrapper">  
	    <div class="content-body"><!-- Basic form layout section start -->
			<section id="basic-form-layouts">
				<div class="match-height">
					<div class="card p-0">
						<div class="card-header">
							<h4 class="card-title" id="basic-layout-tooltip">Service Edit</h4>
							<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
							<div class="heading-elements">
								<ul class="list-inline mb-0">
									<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
									<li><a data-action="reload"><i class="icon-reload"></i></a></li>
									<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="card-body collapse in">
							<div class="card-block">
								<form class="form" method="post" id="form" enctype="multipart/form-data" action="<?php echo e(route('admin.service.store')); ?>">
									<?php echo csrf_field(); ?>
									<input type="hidden" name="id" value="<?php echo e($service->id); ?>">
									<div class="form-body">
										<div class="form-group">
											<label>Title</label>
											<input type="text" class="form-control" placeholder="Title" name="title" value="<?php echo e($service->title); ?>">
										</div>
										<div class="form-group">
											<label>Image</label>
											<div class="">
											  <input type="file" id="file" name="Image" />
											  <small><strong>Standard Image dimension: (Width: 600px, Height:340px)</strong></small>
											  </div>
											  <div class="img_upload01">
											  	<img src="<?php echo e(url('public/images/services/'.$service->image)); ?>" >
											  </div>
										</div>
										<div class="form-group">
											<label>Descripton</label>
											<textarea rows="5" class="form-control" name="description" id="summernote" placeholder="Description..."><?php echo e($service->description); ?></textarea>
										</div>
										<div class="form-group">
										  	<label for="ad_category">Status</label>
										  	<select class="form-control" name="Status">
										    	<option value="1" <?php echo e(($service->status == 1 ? "selected":"")); ?>>Active</option>
										    	<option value="0" <?php echo e(($service->status == 0 ? "selected":"")); ?>>In-Active</option>
										  	</select>
										</div>
										<div class="form-actions">
											<button type="submit" class="btn btn-primary">
												<i class="icon-check2"></i> Save
											</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</section><!-- // Basic form layout section end -->
	    </div>
	</div>
</div>
<style type="text/css">
  form .error {
      color: #FF0000;
  }
</style>
 <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#summernote').summernote({
              height: 600,   // To adjust height (don't use px)
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('validations'); ?>
$('#form').validate({ 
  rules: {
      title: {
          required: true
      },
      description: {
          required: true
      },
  }
});
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/assign/resources/views/admin/pages/form/edit_form.blade.php ENDPATH**/ ?>