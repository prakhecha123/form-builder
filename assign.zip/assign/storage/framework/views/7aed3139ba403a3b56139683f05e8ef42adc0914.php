<?php $__env->startSection('title', 'Edit Profile'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-content content container-fluid">
  <div class="content-wrapper">
    <div class="content-header row"></div>
    <div class="content-body"><!-- stats -->
        <section id="basic-form-layouts">
          <div class="match-height">
              <div class="card p-0">
                <div class="card-header">
                  <h4 class="card-title" id="basic-layout-form">Admin Profile</h4>
                  <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                  <div class="heading-elements">
                    <ul class="list-inline mb-0">
                      <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                      <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                      <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                      <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                    </ul>
                  </div>
                </div>
                <div class="card-body collapse in">
                  <div class="card-block">
                    <form class="form" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                      <input type="hidden" name="SiteId" value="<?php echo e($admin->website_id); ?>">
                      <div class="form-body">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="projectinput1">Name</label>
                              <input type="text" class="form-control" placeholder="First Name" name="Name" value="<?php echo e($admin->name); ?>">
                              <?php if($errors->has('Name')): ?>
                                <div class= "alert alert-danger admin_login_alert"><?php echo e($errors->first('Name')); ?></div>
                              <?php endif; ?>   
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="projectinput3">User Name</label>
                              <input type="text" class="form-control" placeholder="user name" name="UserName" value="<?php echo e($admin->username); ?>">
                              <?php if($errors->has('userName')): ?>
                                  <div class= "alert alert-danger admin_login_alert"><?php echo e($errors->first('UserName')); ?></div>
                              <?php endif; ?>   
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="projectinput3">E-mail</label>
                              <input type="text" class="form-control" placeholder="E-mail" name="Email" value="<?php echo e($admin->email); ?>">
                              <?php if($errors->has('Email')): ?>
                                  <div class= "alert alert-danger admin_login_alert"><?php echo e($errors->first('Email')); ?></div>
                              <?php endif; ?>  
                            </div>
                          </div>
                        </div>
                    
                            </div>
                          </div>
                        </div>
                      <div class="form-actions">
                        <button type="reset" class="btn btn-warning mr-1">
                          <i class="icon-cross2"></i> Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                          <i class="icon-check2"></i> Save
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
          </div>
        </section>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/assign/resources/views/admin/pages/profile/edit_profile.blade.php ENDPATH**/ ?>