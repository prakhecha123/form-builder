
<!DOCTYPE html>
<html lang="en">
<style>
    /* canvas {
        height: 250px !important
    } */
    
    table th,
    table td {
        padding: 3px !important
    }
</style>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Builder</title>

    <link rel="stylesheet" href="<?php echo e(asset('/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/DataTables/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/custom.css')); ?>">

    <script src="<?php echo e(asset('/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/DataTables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/script.js')); ?>"></script>


    <script>
        var form_code = "<?php echo e($code); ?>";
    </script>
    <script src="<?php echo e(asset('/js/form-build-display.js')); ?>"></script>
</head>

<body class='bg-dark'>
    <div class="container pt-4">
        <?php echo $__env->make($code, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <div class="w-100 d-flex justify-content-center">
            <button class="btn btn-primary" form="form-data" id="">Sumbit</button>
        </div>
    </div>
</body>



</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/assign/resources/views/display-form.blade.php ENDPATH**/ ?>