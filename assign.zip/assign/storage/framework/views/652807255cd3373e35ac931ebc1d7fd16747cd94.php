<?php $__env->startSection('title', 'Manage Forms'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-content content container-fluid">
	<div class="content-wrapper">  
	    <div class="content-body"><!-- Basic form layout section start -->
			<section id="basic-form-layouts">
				<div class="match-height">
			        <div class="card p-0">
			            <div class="card-header">
			                <h4 class="card-title">All Forms</h4>
			                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
			                <div class="heading-elements">
			                    <ul class="list-inline mb-0">
			                    	<li><a href="<?php echo e(route('admin.form.add')); ?>"><button type="button" class="btn btn-primary">+New Form</button></a></li>
			                        <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
			                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
			                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li> 
			                    </ul>
			                </div>
			            </div>
			            <div class="card-body collapse in">
				            <div class="card-block">
				            	<?php if(session('success')): ?>
			                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
			                    <?php endif; ?>
				                <div class="table-responsive">
				                    <table class="table">
				                        <thead class="thead-inverse">
				                            <tr>
				                                <th>#</th>
				                                <th>Date Time</th>
				                                <th>Code</th>
				                                <th>Title</th>
				                                <th>Url</th>
				                                <th class="list_action01">Action</th>
				                            </tr>
				                        </thead>
				                        <tbody>
				                        	<?php if(!empty($forms)): ?>
				                        		<?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$from_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                        	  		<tr>
				                                		<td><?php echo e(++$key); ?></td>
				                                		<td><?php echo e(date("M d,Y h:i A",strtotime($from_data->created_at))); ?></td>
				                                		<td><?php echo e($from_data->form_code); ?></td>
				                                		<td><?php echo e($from_data->title); ?></td>
				                                		<td><a href="<?php echo e(route('form.slug', $from_data->form_code)); ?>" target="_blank"><?php echo e(route('form.slug', $from_data->form_code)); ?></a></td>
				                                		
	      												<td class="list_action01">
	      													<!-- <a href="<?php echo e(route('admin.form.edit', ['id'=>$from_data->id])); ?>"><button type="button" class="btn btn-warning">Edit</button></a> -->
	      													<a href="<?php echo e(route('admin.form.delete', $from_data->id)); ?>" onclick="return confirm('Are you sure?')"><button type="button" class="btn btn-danger" >Delete</button></a>
	      												</td>
				                            		</tr>
				                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                            	<?php else: ?>
			                            	<span>Record not available</span>
			                            	<?php endif; ?>
				                        </tbody>
				                    </table>
				                    <?php echo e($forms->links()); ?>

				                </div>
				            </div>
			            </div>
			        </div>
				</div>
			</section>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/assign/resources/views/admin/pages/form/index.blade.php ENDPATH**/ ?>